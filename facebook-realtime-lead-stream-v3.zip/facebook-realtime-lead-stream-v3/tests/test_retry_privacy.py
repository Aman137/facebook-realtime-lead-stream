import pytest

from app.privacy import redact_pii, safe_error
from app.retry import RetryExhaustedError, retry_async


@pytest.mark.asyncio
async def test_retry_succeeds_without_advancing_message():
    calls = 0
    retries = []

    async def operation(attempt):
        nonlocal calls
        calls += 1
        if attempt < 3:
            raise ConnectionError("temporary")
        return "ok"

    result = await retry_async(
        operation,
        attempts=3,
        base_seconds=0,
        on_retry=lambda attempt, error, delay: retries.append((attempt, type(error), delay)),
    )
    assert result == "ok"
    assert calls == 3
    assert [item[0] for item in retries] == [1, 2]


@pytest.mark.asyncio
async def test_retry_exposes_bounded_failure_context():
    async def operation(_attempt):
        raise RuntimeError("always fails")

    with pytest.raises(RetryExhaustedError) as captured:
        await retry_async(operation, attempts=2, base_seconds=0)
    assert captured.value.attempts == 2
    assert isinstance(captured.value.last_error, RuntimeError)


def test_redaction_removes_contact_details_and_secrets():
    raw = (
        "Email jane@example.com or call (214) 555-0199. "
        "Key sk-testsecretvalue123 and https://x.test/?token=abc123 "
        "at postgresql://user:password@db:5432/app"
    )
    result = redact_pii(raw)
    assert "jane@example.com" not in result
    assert "214" not in result
    assert "sk-testsecretvalue123" not in result
    assert "token=abc123" not in result
    assert ":password@" not in result


def test_safe_error_includes_type_but_redacts_message():
    result = safe_error(ValueError("contact jane@example.com"))
    assert result.startswith("ValueError:")
    assert "jane@example.com" not in result
