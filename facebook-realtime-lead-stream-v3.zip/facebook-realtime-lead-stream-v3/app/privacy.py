from __future__ import annotations

import re


EMAIL_PATTERN = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
PHONE_PATTERN = re.compile(
    r"(?<!\w)(?:\+?1[ .-]?)?(?:\(?\d{3}\)?[ .-]?)\d{3}[ .-]?\d{4}(?!\w)"
)
OPENAI_KEY_PATTERN = re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b")
URL_SECRET_PATTERN = re.compile(
    r"(?i)([?&](?:token|key|secret|password|signature)=)[^&\s]+"
)
DSN_PASSWORD_PATTERN = re.compile(r"(://[^:/\s]+:)[^@/\s]+(@)")


def redact_pii(value: str) -> str:
    """Remove common contact details and secrets before text reaches application logs."""

    redacted = EMAIL_PATTERN.sub("[redacted-email]", value)
    redacted = PHONE_PATTERN.sub("[redacted-phone]", redacted)
    redacted = OPENAI_KEY_PATTERN.sub("[redacted-api-key]", redacted)
    redacted = URL_SECRET_PATTERN.sub(r"\1[redacted]", redacted)
    return DSN_PASSWORD_PATTERN.sub(r"\1[redacted]\2", redacted)


def safe_error(error: BaseException, *, redact: bool = True, limit: int = 500) -> str:
    """Return a bounded error description suitable for a dead-letter record."""

    detail = f"{type(error).__name__}: {error}"
    if redact:
        detail = redact_pii(detail)
    return detail[:limit]
