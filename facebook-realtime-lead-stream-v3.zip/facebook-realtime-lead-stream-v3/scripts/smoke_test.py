#!/usr/bin/env python3
"""Run an end-to-end smoke test against the Docker Compose stack."""

from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from uuid import uuid4


def request_json(url: str, *, key_header: str, key: str, payload: dict | None = None):
    body = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json", key_header: key},
        method="POST" if payload is not None else "GET",
    )
    with urllib.request.urlopen(request, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--ingest-key", default="development-key")
    parser.add_argument("--dashboard-key", default="development-dashboard-key")
    parser.add_argument("--timeout", type=int, default=60)
    args = parser.parse_args()

    run_id = uuid4().hex[:10]
    cases = [
        ("qualified", "Frisco Neighbors", "Can anyone recommend a realtor in Frisco?"),
        ("qualified", "Dallas Homeowners", "Need a roofer ASAP in Dallas. Any referrals?"),
        ("rejected", "Neighborhood Chat", "The school picnic begins at noon."),
        ("rejected", "Plano Community", "I already found someone and am no longer looking for a contractor."),
    ]
    expected: dict[str, str] = {}
    try:
        for index, (status, group, text) in enumerate(cases, start=1):
            result = request_json(
                f"{args.base_url}/events",
                key_header="X-API-Key",
                key=args.ingest_key,
                payload={
                    "source": "smoke-test",
                    "source_message_id": f"{run_id}-{index}",
                    "group_name": group,
                    "author": "Smoke Test",
                    "text": text,
                    "post_url": f"https://example.com/smoke/{run_id}/{index}",
                },
            )
            expected[result["event_id"]] = status
    except urllib.error.URLError as error:
        print(f"Could not submit smoke-test events: {error}")
        return 1

    deadline = time.monotonic() + args.timeout
    observed: dict[str, str] = {}
    while time.monotonic() < deadline:
        try:
            events = request_json(
                f"{args.base_url}/events/recent?{urllib.parse.urlencode({'limit': 100})}",
                key_header="X-Dashboard-Key",
                key=args.dashboard_key,
            )
        except urllib.error.URLError:
            time.sleep(2)
            continue
        observed = {row["event_id"]: row["status"] for row in events if row["event_id"] in expected}
        if len(observed) == len(expected) and all(
            observed[event_id] == status for event_id, status in expected.items()
        ):
            print("Smoke test passed.")
            print(f"Processed {len(expected)} events: 2 qualified and 2 rejected.")
            print("Open http://localhost:8025 to confirm two notification emails.")
            return 0
        time.sleep(2)

    print("Smoke test timed out.")
    for event_id, status in expected.items():
        print(f"- {event_id}: expected={status} observed={observed.get(event_id, 'missing')}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
