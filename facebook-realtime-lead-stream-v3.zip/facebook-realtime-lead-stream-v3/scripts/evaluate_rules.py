#!/usr/bin/env python3
"""Measure rule-classifier quality against the included labeled examples."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.classifier import LeadClassifier  # noqa: E402
from app.config import Settings  # noqa: E402
from app.schemas import PublishedEvent  # noqa: E402


def divide(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else 0.0


async def evaluate(dataset_path: Path) -> dict:
    settings = Settings(
        classifier_mode="rules",
        rule_config_path=ROOT / "config" / "lead_rules.json",
        target_groups="",
        allowed_categories="",
        require_market_location=False,
    )
    classifier = LeadClassifier(settings)
    records = [
        json.loads(line)
        for line in dataset_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    tp = fp = tn = fn = 0
    category_correct = category_total = 0
    errors: list[dict] = []
    for row in records:
        event = PublishedEvent(
            event_id=row["id"],
            source="evaluation",
            source_message_id=row["id"],
            group_name=row["group_name"],
            author="Evaluation User",
            text=row["text"],
        )
        decision = await classifier.classify(event)
        expected = bool(row["expected_is_lead"])
        if expected and decision.is_lead:
            tp += 1
        elif expected and not decision.is_lead:
            fn += 1
        elif not expected and decision.is_lead:
            fp += 1
        else:
            tn += 1

        expected_category = row.get("expected_category")
        if expected and expected_category:
            category_total += 1
            if decision.category == expected_category:
                category_correct += 1

        if expected != decision.is_lead or (
            expected and expected_category and decision.category != expected_category
        ):
            errors.append(
                {
                    "id": row["id"],
                    "expected_is_lead": expected,
                    "predicted_is_lead": decision.is_lead,
                    "expected_category": expected_category,
                    "predicted_category": decision.category,
                    "confidence": decision.confidence,
                    "reason": decision.reason,
                }
            )

    precision = divide(tp, tp + fp)
    recall = divide(tp, tp + fn)
    f1 = divide(2 * precision * recall, precision + recall)
    return {
        "dataset": str(dataset_path),
        "examples": len(records),
        "confusion_matrix": {"tp": tp, "fp": fp, "tn": tn, "fn": fn},
        "accuracy": divide(tp + tn, len(records)),
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "category_accuracy": divide(category_correct, category_total),
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dataset",
        type=Path,
        default=ROOT / "data" / "evaluation.jsonl",
    )
    parser.add_argument("--json-output", type=Path)
    parser.add_argument("--min-f1", type=float, default=0.0)
    args = parser.parse_args()

    report = asyncio.run(evaluate(args.dataset))
    matrix = report["confusion_matrix"]
    print(f"Examples:          {report['examples']}")
    print(f"Accuracy:          {report['accuracy']:.1%}")
    print(f"Precision:         {report['precision']:.1%}")
    print(f"Recall:            {report['recall']:.1%}")
    print(f"F1 score:          {report['f1']:.1%}")
    print(f"Category accuracy: {report['category_accuracy']:.1%}")
    print(
        "Confusion matrix:  "
        f"TP={matrix['tp']} FP={matrix['fp']} TN={matrix['tn']} FN={matrix['fn']}"
    )
    if report["errors"]:
        print("\nReview these mismatches:")
        for error in report["errors"]:
            print(
                f"- {error['id']}: lead {error['expected_is_lead']} -> "
                f"{error['predicted_is_lead']}; category "
                f"{error['expected_category']} -> {error['predicted_category']}"
            )

    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(f"\nJSON report: {args.json_output}")
    return 0 if report["f1"] >= args.min_f1 else 1


if __name__ == "__main__":
    raise SystemExit(main())
