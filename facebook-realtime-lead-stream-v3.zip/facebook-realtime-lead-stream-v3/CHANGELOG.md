# Changelog

## Version 3.0.0

- Added a live, authenticated operations dashboard.
- Added JSON statistics and Prometheus-style metrics.
- Added category allowlists and optional required-market filtering.
- Changed hybrid mode to use deterministic rules for clear cases and AI only for ambiguous text.
- Added correct in-place exponential retries before committing Kafka offsets.
- Added dead-letter records in Kafka and PostgreSQL.
- Added per-channel email and webhook delivery tracking.
- Added duplicate counters and processing and notification latency measurements.
- Added log and error redaction for common contact details and secrets.
- Added configurable data retention.
- Added 50 labeled examples, an evaluation command, and broader automated tests.
- Added an end-to-end smoke test and expanded setup documentation.

## Version 2.0.0

- Added Kafka-based event streaming, PostgreSQL storage, rule and OpenAI classification, email and webhook notifications, and Docker Compose setup.
