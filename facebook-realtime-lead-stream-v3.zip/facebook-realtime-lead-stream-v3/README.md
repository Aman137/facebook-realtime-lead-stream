# Facebook Real Time Lead Stream V3

This project watches **authorized incoming Facebook-related events** and processes each event immediately. It decides whether the text contains an actionable real-estate or home-service request, stores the result, suppresses duplicates, and alerts the realtor only for qualified leads.

It is a streaming system, not a batch job. It does **not** scrape Facebook, sign in to a personal account, bypass group privacy, or provide automatic access to private groups. A permitted source must send each post or notification to the intake API.

## System flow

```mermaid
flowchart TD
    A[Authorized event source] --> B[FastAPI intake]
    B --> C[Kafka incoming posts]
    C --> D[Rules or hybrid AI classifier]
    D --> E[PostgreSQL audit store]
    D --> F[Qualified leads topic]
    F --> G[Email or webhook]
    E --> H[Operations dashboard]
    D --> I[Failed events topic]
```

## What V3 includes

- Real-time FastAPI, Kafka, PostgreSQL, and worker services
- Free deterministic rules mode and optional cost-aware hybrid OpenAI mode
- Target-group, category, confidence, and market-location controls
- Stable event IDs and duplicate notification suppression
- In-place exponential retries and a `failed-events` dead-letter topic
- Per-channel delivery tracking so a successful email is not resent when only the webhook fails
- Live dashboard for counts, categories, latency, duplicates, and failures
- Authenticated JSON and Prometheus-style monitoring endpoints
- Contact-detail and secret redaction for stored error messages and logs
- Automatic data-retention cleanup
- 50 labeled evaluation examples and a repeatable precision/recall report
- Automated unit tests and an end-to-end smoke-test script
- A beginner execution guide in `docs`

The included rule baseline scores 100% precision and recall on the included 50-example test set. That set is a development baseline, not proof of production accuracy. Add real, permissioned examples from the intended groups before deployment.

## Fastest setup on Windows

### 1 Install the required tool

Install and open [Docker Desktop](https://www.docker.com/products/docker-desktop/). Wait until Docker Desktop reports that its engine is running.

Python is optional for the main demo. Install [Python](https://www.python.org/downloads/) only if you want to run the evaluation, smoke test, or unit tests from Windows.

### 2 Extract and open the project

Extract the ZIP. Open the extracted `facebook-realtime-lead-stream-v3` folder in File Explorer. Click the address bar, type `powershell`, and press Enter.

### 3 Create the environment file

```powershell
Copy-Item .env.example .env
```

For a local demo, the development keys already work. Before any shared or public deployment, replace both keys in `.env` with long random values.

### 4 Start the streaming stack

```powershell
docker compose up --build -d
```

The first build can take several minutes. Check the containers:

```powershell
docker compose ps
```

Wait until `kafka`, `postgres`, and `api` are healthy. The classifier and notifier should show `Up`.

### 5 Open the project

- Dashboard: <http://localhost:8000/dashboard>
- Interactive API: <http://localhost:8000/docs>
- Demo email inbox: <http://localhost:8025>
- Readiness check: <http://localhost:8000/health/ready>

Enter `development-dashboard-key` on the dashboard. This is the default `DASHBOARD_API_KEY` in `.env`.

### 6 Send the sample events

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\send-sample.ps1
```

Expected result:

- Two events become qualified leads.
- One completed contractor request is rejected.
- Two messages appear in the MailHog inbox.
- The dashboard updates within about five seconds.

The sample IDs are deliberately stable. Running the script again tests duplicate suppression instead of sending new notification emails.

### 7 Run the full smoke test

If Python is installed:

```powershell
python .\scripts\smoke_test.py
```

This sends four new events and waits for two qualified and two rejected decisions.

## Configure what counts as a lead

Edit `.env`, save it, and restart the services with `docker compose up -d --force-recreate`.

| Setting | Purpose | Example |
| --- | --- | --- |
| `TARGET_GROUPS` | Accept only named groups; empty accepts all authorized sources | `Frisco Neighbors,Dallas Homeowners` |
| `ALLOWED_CATEGORIES` | Notify only selected lead categories; empty enables all | `Buyer,Seller,Agent Referral` |
| `MARKET_LOCATIONS` | Locations the classifier recognizes | `Dallas,Plano,Frisco` |
| `REQUIRE_MARKET_LOCATION` | Reject a lead when no configured market is identified | `true` |
| `LEAD_CONFIDENCE_THRESHOLD` | Minimum score required for a lead | `0.85` |
| `DATA_RETENTION_DAYS` | Age at which stored events and failures are removed | `30` |
| `MAX_PROCESSING_ATTEMPTS` | Attempts before an event reaches the dead-letter topic | `3` |

To add an exact phrase that must always be rejected, edit `excluded_phrases` in `config/lead_rules.json`.

Supported categories are `Buyer`, `Seller`, `Agent Referral`, `Rental`, `Contractor or Home Service`, and `Investor`.

## Enable hybrid AI classification

First confirm that rules mode works from intake through notification. Then edit `.env`:

```env
CLASSIFIER_MODE=hybrid
OPENAI_API_KEY=your_real_key_here
OPENAI_MODEL=gpt-5-mini
```

Restart the classifier:

```powershell
docker compose up --build -d classifier-worker
```

Hybrid mode keeps high-confidence rule decisions and sends only ambiguous text to the model. Hard policy rejections, such as a blocked group, disabled category, completed request, or missing required market, never go to the model. If the model call fails, the deterministic rule decision is used.

Never commit `.env` or share an API key.

## Connect a permitted real source

Send one event at a time to `POST /events` with the `X-API-Key` header. A suitable source can be:

- An email automation that receives Facebook notification emails the user is authorized to receive
- An n8n email trigger followed by an HTTP Request node
- An approved Meta application with the required permissions
- A browser extension where the signed-in user explicitly submits the visible post
- A CRM, form, or internal application that already has permission to provide the text

Example request body:

```json
{
  "source": "authorized-email-workflow",
  "source_message_id": "unique-source-id-123",
  "group_name": "Frisco Neighbors",
  "author": "Example User",
  "text": "Can anyone recommend a realtor for a first-time buyer in Frisco?",
  "post_url": "https://example.com/authorized-source/123"
}
```

`source_message_id` should be the source system's stable ID. Reusing it produces the same event ID and prevents a second alert.

## Connect n8n, Slack, or HubSpot

Create a production webhook workflow and set:

```env
NOTIFICATION_WEBHOOK_URL=https://your-n8n.example/webhook/qualified-lead
```

The notifier sends the structured lead as JSON and includes the event ID in the `Idempotency-Key` header. In n8n, use that value to prevent duplicate HubSpot records or Slack messages. Keep a human review step before contacting a person.

## Monitoring endpoints

Send `X-Dashboard-Key` to all data endpoints.

| Endpoint | Result |
| --- | --- |
| `/dashboard` | Browser dashboard; prompts for the key |
| `/stats` | Counts, latency, duplicates, and category totals |
| `/events/recent` | Recent qualified, rejected, pending, and failed events |
| `/leads` | Recent qualified leads |
| `/failures` | Dead-letter failure history without raw post text |
| `/metrics` | Prometheus-compatible text metrics |
| `/config/public` | Active non-secret filter settings |
| `/health` | API liveness |
| `/health/ready` | API and PostgreSQL readiness |

## Measure classification quality

Create a Python environment and run the tests:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python .\scripts\evaluate_rules.py --json-output .\evaluation-report.json
python -m pytest -q
```

The evaluation reports accuracy, precision, recall, F1, category accuracy, a confusion matrix, and every mismatch. Add permissioned, anonymized examples to `data/evaluation.jsonl`; do not tune only against the included examples.

## Useful commands

```powershell
# View all logs
docker compose logs -f

# View only classifier logs
docker compose logs -f classifier-worker

# View notification logs
docker compose logs -f notifier-worker

# Restart after editing .env
docker compose up -d --force-recreate

# Stop while keeping PostgreSQL data
docker compose down

# Stop and intentionally delete local PostgreSQL data
docker compose down -v
```

The final command deletes the local database volume and is not reversible.

## Troubleshooting

**Docker command is not recognized:** Install Docker Desktop, reopen PowerShell, and confirm Docker Desktop is running.

**A service is restarting:** Run `docker compose logs --tail=100 SERVICE_NAME`, replacing `SERVICE_NAME` with `api`, `classifier-worker`, or `notifier-worker`.

**Dashboard says the key is incorrect:** Copy the exact `DASHBOARD_API_KEY` value from `.env`. Restart `api` after changing it.

**No emails appear:** Open notifier logs, confirm `ALERT_EMAIL_TO` is not empty, and confirm MailHog is `Up` in `docker compose ps`.

**A sample does not create another email:** That is expected after its first run because the stable sample IDs test duplicate suppression. Run `scripts/smoke_test.py` for fresh IDs.

**Hybrid mode falls back to rules:** Verify `OPENAI_API_KEY`, network access, model availability, and classifier logs. The pipeline intentionally remains available when the model fails.

## Production checklist

- Replace the two development keys and all default database credentials.
- Use TLS and a private network or API gateway for every non-local endpoint.
- Use managed or securely operated Kafka and PostgreSQL services.
- Configure real SMTP or an approved webhook destination.
- Restrict dashboard and metrics access.
- Tune the filters with representative, permissioned local examples.
- Monitor Kafka consumer lag, failed-event counts, and notification latency.
- Set and enforce an appropriate retention period.
- Minimize stored author and post data; remove fields that are not needed.
- Require human review and honor platform, group, privacy, email, and CRM rules.
- Do not deploy unofficial private-group scraping or personal-login automation.

## Project structure

```text
app/                 API, dashboard, classifier, workers, database, privacy, retry logic
config/              Editable lead rules
data/                Fifty labeled evaluation examples
docs/                Step-by-step Word execution guide
scripts/             Sample sender, smoke test, and evaluation tool
tests/               Automated unit and API tests
docker-compose.yml   Complete local streaming stack
```
