from pathlib import Path

import pytest

from app.classifier import LeadClassifier
from app.config import Settings
from app.schemas import LeadDecision, PublishedEvent


ROOT = Path(__file__).resolve().parents[1]


def event(text: str, group: str = "Frisco Neighbors", event_id: str = "advanced-1"):
    return PublishedEvent(
        event_id=event_id,
        source="test",
        source_message_id=event_id,
        group_name=group,
        author="Tester",
        text=text,
    )


def settings(**overrides):
    values = {
        "classifier_mode": "rules",
        "rule_config_path": ROOT / "config" / "lead_rules.json",
    }
    values.update(overrides)
    return Settings(**values)


@pytest.mark.asyncio
async def test_category_allowlist_blocks_other_leads():
    result = await LeadClassifier(settings(allowed_categories="Buyer,Seller")).classify(
        event("Need a roofer ASAP in Frisco. Any recommendations?")
    )
    assert result.is_lead is False
    assert result.rejection_code == "category_not_allowed"


@pytest.mark.asyncio
async def test_required_location_blocks_missing_market():
    result = await LeadClassifier(settings(require_market_location=True)).classify(
        event("Can anyone recommend a realtor?", group="Regional Homeowners")
    )
    assert result.is_lead is False
    assert result.rejection_code == "location_required"


@pytest.mark.asyncio
async def test_non_real_estate_purchase_is_not_a_lead():
    result = await LeadClassifier(settings()).classify(
        event("Looking to buy a used car. Any recommendations?", group="Dallas Auto Club")
    )
    assert result.is_lead is False
    assert result.category == "Other"


@pytest.mark.asyncio
async def test_group_name_alone_does_not_create_category_hit():
    result = await LeadClassifier(settings()).classify(
        event("The community picnic starts at noon.", group="Dallas Real Estate")
    )
    assert result.is_lead is False
    assert result.category == "Other"


@pytest.mark.asyncio
async def test_hybrid_hard_rejection_does_not_call_model():
    configured = settings(classifier_mode="rules")
    classifier = LeadClassifier(configured)
    classifier.settings.classifier_mode = "hybrid"

    class ModelThatMustNotRun:
        async def classify(self, _event):
            raise AssertionError("model should not run for a deterministic rejection")

    classifier.openai = ModelThatMustNotRun()
    result = await classifier.classify(
        event("I already found someone and am no longer looking for a contractor.")
    )
    assert result.is_lead is False
    assert result.rejection_code == "completed_request"


@pytest.mark.asyncio
async def test_hybrid_routes_ambiguous_text_to_model():
    configured = settings(classifier_mode="rules")
    classifier = LeadClassifier(configured)
    classifier.settings.classifier_mode = "hybrid"
    calls = 0

    class FakeModel:
        async def classify(self, _event):
            nonlocal calls
            calls += 1
            return LeadDecision(
                is_lead=True,
                category="Buyer",
                urgency="medium",
                confidence=0.91,
                market_location="Frisco",
                reason="The writer is beginning a home search.",
                method="openai",
            )

    classifier.openai = FakeModel()
    result = await classifier.classify(event("Starting our home search in Frisco soon."))
    assert calls == 1
    assert result.is_lead is True
    assert result.method == "openai"
