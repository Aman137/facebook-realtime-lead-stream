from __future__ import annotations

import asyncio
import logging
import secrets
from contextlib import asynccontextmanager
from uuid import NAMESPACE_URL, uuid5

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import HTMLResponse, PlainTextResponse

from app import db
from app.broker import KafkaPublisher, Publisher
from app.config import get_settings
from app.dashboard import dashboard_html
from app.schemas import AcceptedEvent, LeadEvent, PublishedEvent


LOGGER = logging.getLogger(__name__)


def _event_id(event: LeadEvent) -> str:
    stable_identity = event.source_message_id or "|".join(
        [event.group_name.casefold(), event.text.casefold(), event.post_url or ""]
    )
    return str(uuid5(NAMESPACE_URL, f"{event.source}:{stable_identity}"))


def _keys_match(provided: str | None, configured: str) -> bool:
    return bool(provided) and secrets.compare_digest(provided, configured)


def _prometheus(stats: dict) -> str:
    lines = [
        "# HELP lead_filter_events_total Events accepted into PostgreSQL.",
        "# TYPE lead_filter_events_total gauge",
        f"lead_filter_events_total {stats['total_events']}",
        "# HELP lead_filter_qualified_total Events classified as qualified leads.",
        "# TYPE lead_filter_qualified_total gauge",
        f"lead_filter_qualified_total {stats['qualified']}",
        "# HELP lead_filter_rejected_total Events rejected by the classifier.",
        "# TYPE lead_filter_rejected_total gauge",
        f"lead_filter_rejected_total {stats['rejected']}",
        "# HELP lead_filter_notifications_total Qualified leads successfully notified.",
        "# TYPE lead_filter_notifications_total gauge",
        f"lead_filter_notifications_total {stats['notified']}",
        "# HELP lead_filter_failures_total Unresolved pipeline failures.",
        "# TYPE lead_filter_failures_total gauge",
        f"lead_filter_failures_total {stats['unresolved_failures']}",
        "# HELP lead_filter_duplicates_suppressed_total Duplicate events suppressed.",
        "# TYPE lead_filter_duplicates_suppressed_total gauge",
        f"lead_filter_duplicates_suppressed_total {stats['duplicates_suppressed']}",
        "# HELP lead_filter_processing_milliseconds Average classification processing time.",
        "# TYPE lead_filter_processing_milliseconds gauge",
        f"lead_filter_processing_milliseconds {stats['avg_processing_ms']:.3f}",
        "# HELP lead_filter_notification_latency_milliseconds Average intake-to-notification latency.",
        "# TYPE lead_filter_notification_latency_milliseconds gauge",
        f"lead_filter_notification_latency_milliseconds {stats['avg_notification_latency_ms']:.3f}",
    ]
    return "\n".join(lines) + "\n"


def create_app(publisher: Publisher | None = None) -> FastAPI:
    settings = get_settings()
    supplied_publisher = publisher

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        logging.basicConfig(
            level=getattr(logging, settings.log_level.upper(), logging.INFO),
            format="%(asctime)s %(levelname)s %(name)s %(message)s",
        )
        if supplied_publisher is None:
            await asyncio.to_thread(db.init_database, settings.database_url)
        active_publisher = supplied_publisher or KafkaPublisher(settings.kafka_bootstrap_servers)
        await active_publisher.start()
        app.state.publisher = active_publisher
        try:
            yield
        finally:
            await active_publisher.stop()

    application = FastAPI(
        title=settings.app_name,
        version="3.0.0",
        description="Receive authorized post events and publish them to the real-time lead pipeline.",
        lifespan=lifespan,
    )

    async def require_dashboard_key(
        x_dashboard_key: str | None = Header(default=None, alias="X-Dashboard-Key"),
    ) -> None:
        if not _keys_match(x_dashboard_key, settings.dashboard_api_key):
            raise HTTPException(status_code=401, detail="Invalid or missing dashboard key")

    @application.get("/", response_class=HTMLResponse)
    async def home() -> str:
        return """
        <!doctype html><html lang="en"><head><meta charset="utf-8"><title>Real Time Lead Stream</title></head>
        <body style="font-family:system-ui;max-width:760px;margin:48px auto;padding:0 20px;color:#172033">
        <h1>Real Time Lead Stream V3</h1>
        <p>The authorized event intake and streaming pipeline are running.</p>
        <ul><li><a href="/dashboard">Open operations dashboard</a></li>
        <li><a href="/docs">Open interactive API documentation</a></li>
        <li><a href="/health/ready">Check readiness</a></li></ul>
        </body></html>
        """

    @application.get("/dashboard", response_class=HTMLResponse)
    async def dashboard() -> str:
        return dashboard_html(settings.dashboard_refresh_seconds)

    @application.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "service": "event-intake", "version": "3.0.0"}

    @application.get("/health/ready")
    async def readiness() -> dict[str, str]:
        try:
            ready = await asyncio.to_thread(db.database_is_ready, settings.database_url)
        except Exception as error:
            LOGGER.warning("Readiness database check failed (%s)", type(error).__name__)
            raise HTTPException(status_code=503, detail="Database is not ready") from error
        if not ready:
            raise HTTPException(status_code=503, detail="Database is not ready")
        return {"status": "ready", "database": "ok", "event_publisher": "ok"}

    @application.post("/events", response_model=AcceptedEvent, status_code=202)
    async def receive_event(
        event: LeadEvent,
        x_api_key: str | None = Header(default=None, alias="X-API-Key"),
    ) -> AcceptedEvent:
        if settings.ingest_api_key and not _keys_match(x_api_key, settings.ingest_api_key):
            raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key")
        event_id = _event_id(event)
        published = PublishedEvent(event_id=event_id, **event.model_dump())
        try:
            await application.state.publisher.publish(
                settings.kafka_incoming_topic,
                published.model_dump(mode="json"),
                event_id,
            )
        except Exception as error:
            LOGGER.warning("Could not publish incoming event (%s)", type(error).__name__)
            raise HTTPException(status_code=503, detail="Event stream is temporarily unavailable") from error
        return AcceptedEvent(event_id=event_id, topic=settings.kafka_incoming_topic)

    @application.get("/leads", dependencies=[Depends(require_dashboard_key)])
    async def leads(limit: int = Query(default=50, ge=1, le=200)):
        try:
            return await asyncio.to_thread(db.recent_qualified_leads, settings.database_url, limit)
        except Exception as error:
            LOGGER.warning("Could not read qualified leads (%s)", type(error).__name__)
            raise HTTPException(status_code=503, detail="Lead database is temporarily unavailable") from error

    @application.get("/events/recent", dependencies=[Depends(require_dashboard_key)])
    async def recent_events(limit: int = Query(default=50, ge=1, le=200)):
        return await asyncio.to_thread(db.recent_events, settings.database_url, limit)

    @application.get("/failures", dependencies=[Depends(require_dashboard_key)])
    async def failures(limit: int = Query(default=50, ge=1, le=200)):
        return await asyncio.to_thread(db.recent_failures, settings.database_url, limit)

    @application.get("/stats", dependencies=[Depends(require_dashboard_key)])
    async def stats():
        return await asyncio.to_thread(db.pipeline_stats, settings.database_url)

    @application.get("/metrics", response_class=PlainTextResponse, dependencies=[Depends(require_dashboard_key)])
    async def metrics() -> str:
        stats = await asyncio.to_thread(db.pipeline_stats, settings.database_url)
        return _prometheus(stats)

    @application.get("/config/public", dependencies=[Depends(require_dashboard_key)])
    async def public_config() -> dict:
        return {
            "classifier_mode": settings.classifier_mode,
            "lead_confidence_threshold": settings.lead_confidence_threshold,
            "target_groups": settings.target_group_list,
            "market_locations": settings.market_location_list,
            "allowed_categories": settings.allowed_category_list,
            "require_market_location": settings.require_market_location,
            "data_retention_days": settings.data_retention_days,
            "max_processing_attempts": settings.max_processing_attempts,
        }

    return application


app = create_app()
