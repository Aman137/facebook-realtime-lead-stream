from __future__ import annotations

import asyncio
import json
import logging
from time import perf_counter
from typing import Any

from aiokafka import AIOKafkaConsumer

from app import db
from app.broker import KafkaPublisher, Publisher
from app.classifier import LeadClassifier
from app.config import Settings, get_settings
from app.privacy import safe_error
from app.retry import RetryExhaustedError, retry_async
from app.schemas import DeadLetterEvent, ProcessedLead, PublishedEvent


LOGGER = logging.getLogger(__name__)


async def initialize_database(database_url: str) -> None:
    for attempt in range(1, 13):
        try:
            await asyncio.to_thread(db.init_database, database_url)
            return
        except Exception:
            if attempt == 12:
                raise
            LOGGER.warning("Database is not ready; retrying in 2 seconds")
            await asyncio.sleep(2)


async def process_event(
    settings: Settings,
    classifier: LeadClassifier,
    publisher: Publisher,
    raw_event: dict[str, Any],
) -> str:
    event = PublishedEvent.model_validate(raw_event)
    already_processed = await asyncio.to_thread(
        db.event_is_processed, settings.database_url, event.event_id
    )
    if already_processed:
        await asyncio.to_thread(db.mark_duplicate, settings.database_url, event.event_id)
        LOGGER.info("Skipping duplicate processed event %s", event.event_id)
        return "duplicate"

    await asyncio.to_thread(db.save_received_event, settings.database_url, event)
    started = perf_counter()
    decision = await classifier.classify(event)
    processing_ms = (perf_counter() - started) * 1000
    processed = ProcessedLead(
        event=event,
        decision=decision,
        processing_ms=round(processing_ms, 3),
    )
    await asyncio.to_thread(db.save_decision, settings.database_url, processed)

    payload = processed.model_dump(mode="json")
    await publisher.publish(settings.kafka_decisions_topic, payload, event.event_id)
    if decision.is_lead:
        await publisher.publish(settings.kafka_qualified_topic, payload, event.event_id)
        LOGGER.info(
            "Qualified lead %s category=%s confidence=%.2f processing_ms=%.1f",
            event.event_id,
            decision.category,
            decision.confidence,
            processing_ms,
        )
        return "qualified"

    LOGGER.info(
        "Rejected event %s code=%s confidence=%.2f processing_ms=%.1f",
        event.event_id,
        decision.rejection_code or "none",
        decision.confidence,
        processing_ms,
    )
    return "rejected"


async def process_with_retry(
    settings: Settings,
    classifier: LeadClassifier,
    publisher: Publisher,
    raw_event: dict[str, Any],
) -> str:
    event_id = str(raw_event.get("event_id", "unknown"))

    def on_retry(attempt: int, error: BaseException, delay: float) -> None:
        LOGGER.warning(
            "Event %s attempt %d failed with %s; retrying in %.1f seconds",
            event_id,
            attempt,
            type(error).__name__,
            delay,
        )

    try:
        return await retry_async(
            lambda _attempt: process_event(settings, classifier, publisher, raw_event),
            attempts=settings.max_processing_attempts,
            base_seconds=settings.retry_base_seconds,
            on_retry=on_retry,
        )
    except RetryExhaustedError as exhausted:
        failure = DeadLetterEvent(
            stage="classification",
            event_id=event_id,
            attempts=exhausted.attempts,
            error=safe_error(
                exhausted.last_error,
                redact=settings.pii_log_redaction,
            ),
            payload=raw_event,
        )
        await publisher.publish(
            settings.kafka_failed_topic,
            failure.model_dump(mode="json"),
            event_id,
        )
        try:
            await asyncio.to_thread(db.record_failure, settings.database_url, failure)
        except Exception as database_error:
            LOGGER.warning(
                "Dead-letter event %s was published but could not be recorded in PostgreSQL (%s)",
                event_id,
                type(database_error).__name__,
            )
        LOGGER.error("Event %s moved to the failed-events topic", event_id)
        return "failed"


async def run() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    await initialize_database(settings.database_url)
    removed = await asyncio.to_thread(
        db.cleanup_old_records,
        settings.database_url,
        settings.data_retention_days,
    )
    if removed["events_deleted"] or removed["failures_deleted"]:
        LOGGER.info("Applied configured data retention: %s", removed)

    classifier = LeadClassifier(settings)
    publisher = KafkaPublisher(settings.kafka_bootstrap_servers)
    consumer = AIOKafkaConsumer(
        settings.kafka_incoming_topic,
        bootstrap_servers=settings.kafka_bootstrap_servers,
        group_id="lead-classifier-v3",
        auto_offset_reset="earliest",
        enable_auto_commit=False,
        value_deserializer=lambda value: json.loads(value.decode("utf-8")),
    )
    await publisher.start()
    await consumer.start()
    LOGGER.info("Classifier worker is listening on %s", settings.kafka_incoming_topic)
    try:
        async for message in consumer:
            await process_with_retry(settings, classifier, publisher, message.value)
            await consumer.commit()
    finally:
        await consumer.stop()
        await publisher.stop()


if __name__ == "__main__":
    asyncio.run(run())
