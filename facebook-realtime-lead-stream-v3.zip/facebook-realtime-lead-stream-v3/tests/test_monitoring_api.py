from fastapi.testclient import TestClient

from app import db
from app.broker import InMemoryPublisher
from app.config import get_settings
from app.main import create_app


STATS = {
    "total_events": 12,
    "qualified": 4,
    "rejected": 7,
    "pending": 0,
    "failed_events": 1,
    "notified": 3,
    "duplicates_suppressed": 2,
    "avg_processing_ms": 12.5,
    "avg_notification_latency_ms": 240.0,
    "unresolved_failures": 1,
    "qualified_by_category": [{"category": "Buyer", "count": 4}],
}


def build_client(monkeypatch):
    monkeypatch.setenv("DASHBOARD_API_KEY", "dashboard-test-key")
    monkeypatch.setenv("INGEST_API_KEY", "ingest-test-key")
    get_settings.cache_clear()
    monkeypatch.setattr(db, "pipeline_stats", lambda _database_url: STATS)
    return TestClient(create_app(InMemoryPublisher()))


def test_dashboard_page_is_available_without_exposing_data(monkeypatch):
    with build_client(monkeypatch) as client:
        response = client.get("/dashboard")
    assert response.status_code == 200
    assert "Lead Stream Operations" in response.text
    assert "dashboard-test-key" not in response.text
    get_settings.cache_clear()


def test_stats_require_dashboard_key(monkeypatch):
    with build_client(monkeypatch) as client:
        missing = client.get("/stats")
        accepted = client.get("/stats", headers={"X-Dashboard-Key": "dashboard-test-key"})
    assert missing.status_code == 401
    assert accepted.status_code == 200
    assert accepted.json()["qualified"] == 4
    get_settings.cache_clear()


def test_prometheus_metrics_are_exposed_with_authentication(monkeypatch):
    with build_client(monkeypatch) as client:
        response = client.get(
            "/metrics",
            headers={"X-Dashboard-Key": "dashboard-test-key"},
        )
    assert response.status_code == 200
    assert "lead_filter_qualified_total 4" in response.text
    assert "lead_filter_processing_milliseconds 12.500" in response.text
    get_settings.cache_clear()


def test_public_config_omits_secrets(monkeypatch):
    with build_client(monkeypatch) as client:
        response = client.get(
            "/config/public",
            headers={"X-Dashboard-Key": "dashboard-test-key"},
        )
    body = response.json()
    assert response.status_code == 200
    assert "dashboard_api_key" not in body
    assert "openai_api_key" not in body
    assert body["classifier_mode"] == "rules"
    get_settings.cache_clear()
