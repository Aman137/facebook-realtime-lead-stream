from __future__ import annotations

import asyncio
import json
import logging
import smtplib
from collections.abc import Awaitable, Callable
from email.message import EmailMessage
from typing import Any

import httpx
from aiokafka import AIOKafkaConsumer

from app import db
from app.broker import KafkaPublisher, Publisher
from app.config import Settings, get_settings
from app.privacy import safe_error
from app.retry import RetryExhaustedError, retry_async
from app.schemas import DeadLetterEvent, ProcessedLead
from app.worker import initialize_database


LOGGER = logging.getLogger(__name__)


def send_email(settings: Settings, lead: ProcessedLead) -> None:
    message = EmailMessage()
    message["Subject"] = f"New {lead.decision.category} lead from {lead.event.group_name}"
    message["From"] = settings.alert_email_from
    message["To"] = settings.alert_email_to
    message["Message-ID"] = f"<{lead.event.event_id}@facebook-lead-filter.local>"
    message.set_content(
        "\n".join(
            [
                f"Category: {lead.decision.category}",
                f"Urgency: {lead.decision.urgency}",
                f"Confidence: {lead.decision.confidence:.0%}",
                f"Group: {lead.event.group_name}",
                f"Author: {lead.event.author or 'Unknown'}",
                f"Location: {lead.decision.market_location or 'Not detected'}",
                f"Reason: {lead.decision.reason}",
                "",
                lead.event.text,
                "",
                f"Source: {lead.event.post_url or 'No URL supplied'}",
                f"Event ID: {lead.event.event_id}",
            ]
        )
    )
    with smtplib.SMTP(
        settings.smtp_host,
        settings.smtp_port,
        timeout=settings.notification_timeout_seconds,
    ) as smtp:
        if settings.smtp_starttls:
            smtp.starttls()
        if settings.smtp_username:
            smtp.login(settings.smtp_username, settings.smtp_password or "")
        smtp.send_message(message)


async def send_webhook(settings: Settings, lead: ProcessedLead) -> None:
    if not settings.notification_webhook_url:
        return
    async with httpx.AsyncClient(timeout=settings.notification_timeout_seconds) as client:
        response = await client.post(
            settings.notification_webhook_url,
            json=lead.model_dump(mode="json"),
            headers={"Idempotency-Key": lead.event.event_id},
        )
        response.raise_for_status()


async def _deliver_channel(
    settings: Settings,
    lead: ProcessedLead,
    channel: str,
    operation: Callable[[], Awaitable[None]],
) -> None:
    sent = await asyncio.to_thread(
        db.notification_channel_was_sent,
        settings.database_url,
        lead.event.event_id,
        channel,
    )
    if sent:
        LOGGER.info("Skipping completed %s delivery for %s", channel, lead.event.event_id)
        return

    try:
        await operation()
    except Exception as error:
        description = safe_error(error, redact=settings.pii_log_redaction)
        try:
            await asyncio.to_thread(
                db.mark_notification_channel_failed,
                settings.database_url,
                lead.event.event_id,
                channel,
                description,
            )
        except Exception:
            LOGGER.warning("Could not record failed %s delivery for %s", channel, lead.event.event_id)
        raise

    await asyncio.to_thread(
        db.mark_notification_channel_sent,
        settings.database_url,
        lead.event.event_id,
        channel,
    )


async def deliver(settings: Settings, lead: ProcessedLead) -> None:
    if settings.alert_email_to:
        await _deliver_channel(
            settings,
            lead,
            "email",
            lambda: asyncio.to_thread(send_email, settings, lead),
        )
    if settings.notification_webhook_url:
        await _deliver_channel(
            settings,
            lead,
            "webhook",
            lambda: send_webhook(settings, lead),
        )


async def notify_lead(settings: Settings, raw_lead: dict[str, Any]) -> str:
    lead = ProcessedLead.model_validate(raw_lead)
    sent = await asyncio.to_thread(
        db.notification_was_sent,
        settings.database_url,
        lead.event.event_id,
    )
    if sent:
        LOGGER.info("Skipping duplicate notification %s", lead.event.event_id)
        return "duplicate"

    await deliver(settings, lead)
    await asyncio.to_thread(db.mark_notified, settings.database_url, lead.event.event_id)
    LOGGER.info("Notification delivered for %s", lead.event.event_id)
    return "notified"


async def notify_with_retry(
    settings: Settings,
    publisher: Publisher,
    raw_lead: dict[str, Any],
) -> str:
    event_id = str(raw_lead.get("event", {}).get("event_id", "unknown"))

    def on_retry(attempt: int, error: BaseException, delay: float) -> None:
        LOGGER.warning(
            "Notification %s attempt %d failed with %s; retrying in %.1f seconds",
            event_id,
            attempt,
            type(error).__name__,
            delay,
        )

    try:
        return await retry_async(
            lambda _attempt: notify_lead(settings, raw_lead),
            attempts=settings.max_processing_attempts,
            base_seconds=settings.retry_base_seconds,
            on_retry=on_retry,
        )
    except RetryExhaustedError as exhausted:
        failure = DeadLetterEvent(
            stage="notification",
            event_id=event_id,
            attempts=exhausted.attempts,
            error=safe_error(
                exhausted.last_error,
                redact=settings.pii_log_redaction,
            ),
            payload=raw_lead,
        )
        await publisher.publish(
            settings.kafka_failed_topic,
            failure.model_dump(mode="json"),
            event_id,
        )
        try:
            await asyncio.to_thread(db.record_failure, settings.database_url, failure)
        except Exception as database_error:
            LOGGER.warning(
                "Dead-letter notification %s was published but not recorded in PostgreSQL (%s)",
                event_id,
                type(database_error).__name__,
            )
        LOGGER.error("Notification %s moved to the failed-events topic", event_id)
        return "failed"


async def run() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    await initialize_database(settings.database_url)

    publisher = KafkaPublisher(settings.kafka_bootstrap_servers)
    consumer = AIOKafkaConsumer(
        settings.kafka_qualified_topic,
        bootstrap_servers=settings.kafka_bootstrap_servers,
        group_id="lead-notifier-v3",
        auto_offset_reset="earliest",
        enable_auto_commit=False,
        value_deserializer=lambda value: json.loads(value.decode("utf-8")),
    )
    await publisher.start()
    await consumer.start()
    LOGGER.info("Notifier worker is listening on %s", settings.kafka_qualified_topic)
    try:
        async for message in consumer:
            await notify_with_retry(settings, publisher, message.value)
            await consumer.commit()
    finally:
        await consumer.stop()
        await publisher.stop()


if __name__ == "__main__":
    asyncio.run(run())
