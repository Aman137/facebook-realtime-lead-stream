# Validation Record

Validation date: 2026-09-29

## Completed checks

- Python compilation passed for `app`, `scripts`, and `tests`.
- Dependency consistency check passed.
- JSON, JSONL, and Docker Compose YAML parsing passed.
- Automated test suite: 22 passed.
- Included rule evaluation: 50 examples, 25 positive and 25 negative.
- Included evaluation precision: 100%.
- Included evaluation recall: 100%.
- Included evaluation F1: 100%.
- Included evaluation category accuracy: 100%.
- Word guide: 11 pages rendered and visually inspected.
- Word guide accessibility audit: zero high, medium, or low findings.

The evaluation set is a controlled development baseline, not a production-accuracy guarantee. Add representative, permissioned examples from the intended groups and markets before deployment.

## Remaining local acceptance test

Docker was not available in the build environment, so the six-container stack was not executed there. After extracting the ZIP on a computer with Docker Desktop, run:

```powershell
Copy-Item .env.example .env
docker compose up --build -d
python .\scripts\smoke_test.py
```

Then confirm two new messages in MailHog at `http://localhost:8025` and inspect the dashboard at `http://localhost:8000/dashboard`.
