from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar


T = TypeVar("T")


class RetryExhaustedError(RuntimeError):
    def __init__(self, attempts: int, last_error: BaseException):
        super().__init__(f"operation failed after {attempts} attempts")
        self.attempts = attempts
        self.last_error = last_error


async def retry_async(
    operation: Callable[[int], Awaitable[T]],
    *,
    attempts: int,
    base_seconds: float,
    on_retry: Callable[[int, BaseException, float], None] | None = None,
) -> T:
    """Retry one message in place so Kafka does not advance past a transient failure."""

    last_error: BaseException | None = None
    for attempt in range(1, attempts + 1):
        try:
            return await operation(attempt)
        except Exception as error:
            last_error = error
            if attempt >= attempts:
                break
            delay = base_seconds * (2 ** (attempt - 1))
            if on_retry:
                on_retry(attempt, error, delay)
            if delay:
                await asyncio.sleep(delay)

    assert last_error is not None
    raise RetryExhaustedError(attempts, last_error) from last_error
