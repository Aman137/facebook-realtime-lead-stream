import pytest

from app import db
from app.broker import InMemoryPublisher
from app.config import Settings
from app.schemas import LeadDecision
from app.worker import process_event


RAW_EVENT = {
    "event_id": "worker-event-1",
    "source": "test",
    "source_message_id": "worker-message-1",
    "group_name": "Frisco Neighbors",
    "author": "Tester",
    "text": "Can anyone recommend a realtor in Frisco?",
}


@pytest.mark.asyncio
async def test_worker_publishes_decision_and_qualified_lead(monkeypatch):
    saved = []
    monkeypatch.setattr(db, "event_is_processed", lambda *_args: False)
    monkeypatch.setattr(db, "save_received_event", lambda *_args: None)
    monkeypatch.setattr(db, "save_decision", lambda _url, processed: saved.append(processed))

    class FakeClassifier:
        async def classify(self, _event):
            return LeadDecision(
                is_lead=True,
                category="Agent Referral",
                urgency="medium",
                confidence=0.95,
                market_location="Frisco",
                reason="Clear request for a realtor.",
                method="rules",
            )

    publisher = InMemoryPublisher()
    result = await process_event(Settings(), FakeClassifier(), publisher, RAW_EVENT)
    assert result == "qualified"
    assert [message[0] for message in publisher.messages] == [
        "lead-decisions",
        "qualified-leads",
    ]
    assert len(saved) == 1
    assert saved[0].processing_ms >= 0


@pytest.mark.asyncio
async def test_worker_suppresses_already_processed_event(monkeypatch):
    duplicates = []
    monkeypatch.setattr(db, "event_is_processed", lambda *_args: True)
    monkeypatch.setattr(db, "mark_duplicate", lambda _url, event_id: duplicates.append(event_id))

    class ClassifierThatMustNotRun:
        async def classify(self, _event):
            raise AssertionError("duplicate event must not be classified again")

    publisher = InMemoryPublisher()
    result = await process_event(Settings(), ClassifierThatMustNotRun(), publisher, RAW_EVENT)
    assert result == "duplicate"
    assert duplicates == ["worker-event-1"]
    assert publisher.messages == []
